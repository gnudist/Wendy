use strict;

package mod_hello; # 'mod_' + MODULENAME

sub wendy_handler
{
	my $WOBJ = shift;

	my %outcome = (
			ctype => 'text/plain',
		        code  => 200,
			file => '' );

	$outcome{ "data" } = 'Hello from generic Wendy module!';

	return \%outcome;
}

1;

