

DROP TABLE hello_table;

