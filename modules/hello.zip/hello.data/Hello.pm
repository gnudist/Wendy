#!/usr/bin/perl

use strict;

package Wendy::Modules::Hello;
require Exporter;

our @ISA         = qw( Exporter );
our @EXPORT      = qw( hello_function );
our @EXPORT_OK   = qw( hello_function );
our %EXPORT_TAGS = ( hellovars => [ qw( $hello_var ) ] );
our $VERSION     = 1.00;

our $hello_var = 'test';

sub hello_function
{
        return "Hello, world!";
}

1;

