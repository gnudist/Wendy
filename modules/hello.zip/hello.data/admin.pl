use strict;

package mod_hello; # 'mod_' + MODULENAME

use Wendy::Modules::Hello; # our installed module available

sub admin
{
	my $WOBJ = shift;

	my %outcome = (
			ctype => 'text/plain',
		        code  => 200,
			file => '' );


	use Data::Dumper;

# my $WOBJ = &Wendy::__get_wobj();

	$outcome{ "data" } = 'Hello from generic Wendy module admin:<p>' . '<pre>' . Dumper( \%ENV ) . "\n" . Dumper( $WOBJ ) . '</pre>';

#	return \%outcome; # can return full $outcome object!


	$outcome{ "data" } .= '<p>' . &hello_function();

	return $outcome{ "data" }; # can return just html page text
}

1;

