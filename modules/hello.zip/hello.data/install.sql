
CREATE TABLE hello_table (
id serial primary key,
value varchar(32) );


INSERT INTO hello_table ( value ) values ( '1' );
INSERT INTO hello_table ( value ) values ( '2' );
INSERT INTO hello_table ( value ) values ( '3' );