use strict;

package mod_news_export;

use XML::Writer;
use HTML::Strip;
use Wendy::Templates;
use Wendy::Modules::News;
use URI;
use Date::Manip;
use DateTime;
use IO::String;


sub wendy_handler
{
	my $WOBJ = shift;

	&sload_macros();
	my %options = &nm_get_options( $WOBJ -> { 'HOST' } -> { 'id' } );

	my $host_uri = URI -> new();
	$host_uri -> scheme( 'http' );
	$host_uri -> host( $WOBJ -> { 'HOST' } -> { 'host' } );

	my %outcome = ( ctype => 'text/xml',
		        code  => 200,
			ttl   => 5 );

	my $outcome = '';
	my $io_obj = IO::String -> new( $outcome );
	my $writer = new XML::Writer( OUTPUT => $io_obj );
	$writer -> xmlDecl();
	$writer -> startTag( "rss",
                             "version" => "2.0",
                             "xmlns"   => "http://backend.userland.com/rss2" );

	$writer -> startTag( "channel" );

	$writer -> startTag( "title" );
	$writer -> characters( &get_replace( "RSS_TITLE" ) or
			       $options{ 'rss_default_title' } or
			       'Title not set' );
	$writer -> endTag(); # </title>


	$host_uri -> path( '/' );
	
	$writer -> startTag( "link" );
	$writer -> characters( $host_uri -> canonical() -> as_string() );
	$writer -> endTag(); # </link>


	$writer -> startTag( "description" );
	$writer -> characters( &get_replace( "RSS_DESCRIPTION" ) or
			       $options{ 'rss_default_desc' } or
			       'Description not set' );
	$writer -> endTag(); # </description>

	$writer -> startTag( "image" );

	$writer -> startTag( "url" );
	$writer -> characters( $options{ 'rss_logo_image' } );
	$writer -> endTag(); # </url>
    
	$writer -> startTag( "link" );
	$writer -> characters( $host_uri -> canonical() -> as_string() );
	$writer -> endTag(); # </link>
	
	$writer -> startTag( "title" );
	$writer -> characters( &get_replace( 'RSS_IMG_TITLE' ) or
			       $options{ 'rss_default_img_title' } or
			       'Image title not set' );
	$writer -> endTag(); # </title>
	$writer -> endTag(); # </image>

	my %export = &nm_getnews( Client => scalar $WOBJ -> { 'CGI' } -> param( 'cid' ),
				  Host => $WOBJ -> { 'HOST' } -> { 'id' },
				  State => NS_APPROVED,
				  Lng => $WOBJ -> { "RLNGS" } -> { $WOBJ -> { "LNG" } },
				  Limit => ( int( $options{ 'rss_items_limit' } ) or 10 ) );


	foreach my $nid ( sort { $export{ $b } -> { "published" }
				 cmp
				 $export{ $a } -> { "published" } } keys %export )
	{
		$writer -> startTag( "item" );

		$writer -> startTag( "title" );
		$writer -> characters( $export{ $nid } -> { "title" } );
		$writer -> endTag(); # </title>

		$writer -> startTag( "link" );
		$host_uri -> path( '/mod/news/show/' );
		$host_uri -> query_form( news => $export{ $nid } -> { "crosslink" } );
		$writer -> characters( $host_uri -> canonical() -> as_string() );
		$writer -> endTag(); # </link>

		$writer -> startTag( "pubDate" );

		my $published = '';

		{
			my $date = ParseDate( $export{ $nid } -> { "published" } );
			$date =~ /(\d{4})(\d\d)(\d\d)(\d\d):(\d\d):(\d\d)/;

			my $dt = DateTime -> new( year      => $1,
						  month     => $2, 
						  day       => $3,
						  hour      => $4,
						  minute    => $5,
						  second    => $6,
						  time_zone => ( $options{ "local_timezone" } or 'GMT' ) );

			if( $dt )
			{
				$dt -> set_time_zone( 'GMT' );
				my $od = sprintf( "%s, %02d %s %04d %02d:%02d:%02d GMT",
						  $dt -> day_abbr,
						  $dt -> day,
						  $dt -> month_abbr,
						  $dt -> year,
						  $dt -> hour,
						  $dt -> minute,
						  $dt -> second );
				$published = $od;
			} else
			{
				$published = $export{ $nid } -> { "published" };
			}
		}

		$writer -> characters( $published );
		$writer -> endTag(); # </pubDate>

		$writer -> startTag( "description" );
		
		{
			use utf8;
			my $desc_length = ( int( $options{ "rss_desc_len" } ) or 512 );
			my $hs = HTML::Strip -> new();
			my $stripped = $hs -> parse( $export{ $nid } -> { "body" } );
			$writer -> characters( substr( $stripped, 0, $desc_length ) );
		}

		$writer -> endTag(); # </description>
		$writer -> endTag(); # </item>
	}

	$writer -> endTag(); # </channel>
	$writer -> endTag(); # </rss>
	$writer -> end();

	$outcome{ "data" } = $outcome;
	$outcome{ "ttl" } = 600;

	return \%outcome;
}

1;

