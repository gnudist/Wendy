
CREATE SEQUENCE news_crosslnk;

CREATE TABLE news_state (
id INT primary key,
state varchar(32) );

CREATE TABLE news_crosslink (
id INT PRIMARY KEY DEFAULT nextval( 'news_crosslnk' ) );

CREATE TABLE news (
id serial primary key,
author INT REFERENCES weuser(id),
created TIMESTAMP WITHOUT TIME ZONE DEFAULT NOW(),
published TIMESTAMP WITHOUT TIME ZONE DEFAULT NOW(),
host INT REFERENCES host(id),
lng INT REFERENCES language(id),
crosslink INT NOT NULL REFERENCES news_crosslink(id),
state INT REFERENCES news_state (id),
title varchar(512),
body TEXT );

CREATE TABLE news_client (
id serial PRIMARY KEY,
host INT references host(id),
name varchar(128) NOT NULL );

CREATE TABLE news_export (
id serial PRIMARY KEY,
client INT references news_client(id) ON DELETE CASCADE,
news INT references news_crosslink(id) );

CREATE TABLE news_settings (
id serial PRIMARY KEY,
host INT REFERENCES host(id),
field varchar(32) NOT NULL,
value varchar(256) );

ALTER TABLE news_settings ADD CONSTRAINT settings_uniq UNIQUE (host,field);

INSERT INTO news_state ( id, state ) VALUES ( '10', 'Pending' );
INSERT INTO news_state ( id, state ) VALUES ( '20', 'Approved' );

ALTER TABLE news_export ADD CONSTRAINT one_client_one_news UNIQUE (client,news);
ALTER TABLE news ADD CONSTRAINT news_lng UNIQUE (crosslink,lng);
CREATE INDEX crosslnk_idx ON news(crosslink);
