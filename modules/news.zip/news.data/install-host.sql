INSERT INTO news_settings (host,field,value) VALUES ('%HOSTID%','rss_logo_image','http://example.com/link-to-rss-image-logo.gif');
INSERT INTO news_settings (host,field,value) VALUES ('%HOSTID%','rss_default_title','Default rss title');
INSERT INTO news_settings (host,field,value) VALUES ('%HOSTID%','rss_default_desc','Default rss description');
INSERT INTO news_settings (host,field,value) VALUES ('%HOSTID%','rss_default_img_title','Default rss image title');
INSERT INTO news_settings (host,field,value) VALUES ('%HOSTID%','rss_items_limit','10');
INSERT INTO news_settings (host,field,value) VALUES ('%HOSTID%','rss_desc_len','512');
INSERT INTO news_settings (host,field,value) VALUES ('%HOSTID%','local_timezone','Europe/Moscow');


DELETE FROM macros WHERE host='%HOSTID%' AND name IN ( 'RSS_DESCRIPTION', 'RSS_TITLE', 'RSS_IMG_TITLE' ) AND address='mod_news_export';

INSERT INTO macros(name,body,host,address,lng) VALUES ('RSS_DESCRIPTION','Default RSS description in english.','%HOSTID%','mod_news_export','1');

INSERT INTO macros(name,body,host,address,lng) VALUES ('RSS_TITLE','Default RSS description in english.','%HOSTID%','mod_news_export','1');

INSERT INTO macros(name,body,host,address,lng) VALUES ('RSS_IMG_TITLE','Default RSS description in english.','%HOSTID%','mod_news_export','1');

DELETE FROM macros WHERE host='%HOSTID%' AND name IN ( 'RSS_DESCRIPTION', 'RSS_TITLE', 'RSS_IMG_TITLE' ) AND address='mod_news_export' AND lng NOT IN ( SELECT lng FROM hostlanguage WHERE host='%HOSTID%' );

INSERT INTO news_client (host,name) VALUES ('%HOSTID%','Default');
