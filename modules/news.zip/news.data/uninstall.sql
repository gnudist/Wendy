
DELETE FROM news;
DROP TABLE news_export;
DROP TABLE news;
DROP TABLE news_crosslink;
DROP TABLE news_state;
DROP TABLE news_client;
DROP TABLE news_settings;
DROP SEQUENCE news_crosslnk;
