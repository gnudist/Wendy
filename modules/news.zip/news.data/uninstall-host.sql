DELETE FROM news_settings WHERE host='%HOSTID%';
DELETE FROM news_client WHERE host='%HOSTID%';

DELETE FROM macros WHERE host='%HOSTID%' AND name IN ( 'RSS_DESCRIPTION', 'RSS_TITLE', 'RSS_IMG_TITLE' ) AND address='mod_news_export';

