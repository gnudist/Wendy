#!/usr/bin/perl

use strict;

package Wendy::Modules::News;
require Exporter;

use Wendy::Util;
use Wendy::Db;

our @ISA         = qw( Exporter );
our @EXPORT      = qw( NS_PENDING
		       NS_APPROVED
		       nm_getnews
		       nm_getstates
		       nm_getclients
		       nm_getlinks
		       nm_getid
		       nm_get_possible_languages
		       nm_get_options );
our @EXPORT_OK   = qw( NS_PENDING
		       NS_APPROVED
		       nm_getnews
		       nm_getstates
		       nm_getclients
		       nm_getlinks
		       nm_getid
		       nm_get_possible_languages
		       nm_get_options );
### our %EXPORT_TAGS = ( hellovars => [ qw( $hello_var ) ] );
our $VERSION     = 1.00;

use constant {
	NS_PENDING  => 10,
	NS_APPROVED => 20 };
    

sub nm_get_options
{
	my $host = shift;

	my %recs = &meta_get_records( Table => 'news_settings',
				      Where => sprintf( "host=%s", &dbquote( $host ) ) );
	my %out = ();

	foreach my $rid ( keys %recs )
	{
		$out{ $recs{ $rid } -> { 'field' } } = $recs{ $rid } -> { 'value' };
	}

	return %out;
}


sub nm_getnews
{
	my %args = @_;

	my ( $client_id,
	     $from_date,
	     $to_date,
	     $title_like,
	     $body_like,
	     $id,
	     $crosslink,
	     $state,
	     $lng,
	     $hostid,
	     $limit,
	     $offset ) = @args{ "Client",
				"From",
				"To",
				"TitleLike",
				"BodyLike",
				"Id",
				"Crosslink",
				"State",
				"Lng",
				"Host",
				"Limit",
				"Offset" };
	
	my %outcome = ();

	my $whereclause = '1=1';
	my $table = 'news';
	my $fields_sel = undef;

	if( $id )
	{
		my @ids = ();

		if( ref( $id ) )
		{
			@ids = @$id;
		} else
		{
			push @ids, $id;
		}

		$whereclause .= sprintf( " AND news.id IN ( %s )", join( ', ', map { &dbquote( $_ ) } @ids ) );
	} else
	{

		if( $crosslink )
		{
			my @ids = ();
			
			if( ref( $crosslink ) )
			{
				@ids = @$crosslink;
			} else
			{
				push @ids, $crosslink;
			}
			
			$whereclause .= sprintf( " AND news.crosslink IN ( %s )", join( ', ', map { &dbquote( $_ ) } @ids ) );
			
		}

		if( $hostid )
		{
			my @inhost = ();

			if( ref( $hostid ) )
			{
				@inhost = @$hostid;
			} else
			{
				push @inhost, $hostid;
			}
			$whereclause .= sprintf( " AND news.host IN ( %s )",
						 join( ", ", map { &dbquote( $_ ) } @inhost ) );
		}

		if( $from_date )
		{
			$whereclause .= sprintf( " AND DATE(news.published)>=%s",
						 &dbquote( $from_date ) );
		}
		
		if( $to_date )
		{
			$whereclause .= sprintf( " AND DATE(news.published)<=%s",
						 &dbquote( $to_date ) );
		}

		if( $title_like )
		{
			$whereclause .= sprintf( " AND ( news.title ILIKE %s",
						 &dbquote( '%' . $title_like . '%' ) );

			if( $body_like )
			{	
				$whereclause .= sprintf( " OR news.body ILIKE %s )",
							 &dbquote( '%' . $body_like . '%' ) );
			} else
			{
				$whereclause .= ' AND 1=1)';
			}

		} elsif( $body_like )
		{
			$whereclause .= sprintf( " AND news.body ILIKE %s",
						 &dbquote( '%' . $body_like . '%' ) );
		}

		if( $client_id )
		{
			$table = 'news,news_export';
			my @clients = ();
			
			if( ref( $client_id ) )
			{
				@clients = @$client_id;
			} else
			{
				push @clients, $client_id;
			}
			
			
			$whereclause .= sprintf( " AND news_export.news=news.crosslink AND news_export.client IN ( %s ) ",
						 join( ', ', map { &dbquote( $_ ) } @clients ) );
			
			
			$fields_sel = [ 'news.id AS id',
					'news.author AS author',
					'news.created AS created',
					'news.published AS published',
					'news.host AS host',
					'news.lng AS lng',
					'news.crosslink AS crosslink',
					'news.state AS state',
					'news.title AS title',
					'news.body AS body' ];
		}

		if( $state )
		{
			my @states = ();
			if( ref( $state ) )
			{
				@states = @$state;
			} else
			{
				push @states, $state;
			}
			$whereclause .= sprintf( " AND news.state IN ( %s )",
						 join( ', ', map { &dbquote( $_ ) } ( @states ) ) );
		}

		if( $lng )
		{
			my @lngs = ();
			if( ref( $lng ) )
			{
				@lngs = @$lng;
			} else
			{
				push @lngs, $lng;
			}
			$whereclause .= sprintf( " AND news.lng IN ( %s )",
						 join( ', ', map { &dbquote( $_ ) } ( @lngs ) ) );
		}
	}
	
	my $orderfield = undef;
	
	if( $limit )
	{
		$orderfield = 'news.published';
	}

	

	%outcome = &meta_get_records( Table      => $table,
				      Where      => $whereclause,
				      Limit      => $limit,
				      Offset     => $offset,
				      Fields     => $fields_sel,
				      OrderField => $orderfield );

	return %outcome;
}

sub nm_getstates
{
	my %outcome = &meta_get_records( Table => 'news_state' );
	return %outcome;
}

sub nm_getclients
{
	my %args = @_;

	my $whereclause = '1=1';

	if( exists $args{ "Crosslink" } )
	{
		my $link = $args{ "Crosslink" };
		my @ids = ();

		if( ref( $link ) )
		{
			@ids = @$link;
		} else
		{
			push @ids, $link;
		}

		my %recs = &meta_get_records( Table => 'news_export',
					      Where => sprintf( "news IN ( %s )", join( ", ", map { &dbquote( $_ ) } @ids ) )  );

		my @temp = ();
		foreach my $rid ( keys %recs )
		{
			push @temp, $recs{ $rid } -> { "client" };
		}

		unless( scalar @temp )
		{
			push @temp, undef;
		}
		$args{ "Id" } = \@temp;
	}


	if( exists $args{ "Id" } )
	{
		my $id = $args{ "Id" };
		if( ref( $id ) )
		{
			$whereclause .= sprintf( " AND id IN ( %s )", join( ", ", map { &dbquote( $_ ) } @$id ) );
		} else
		{
			$whereclause .= sprintf( " AND id=%s", &dbquote( $id ) );
		}
	}

	if( $args{ "Host" } )
	{
		my $hostie = $args{ "Host" };
		
		if( ref( $hostie ) )
		{
			my @hosts = @$hostie;

			$whereclause .= sprintf( " AND host IN ( %s )",
						 join( ", ", map { &dbquote( $_ ) } @hosts ) );

		} else
		{
			$whereclause .= sprintf( " AND host=%s",
						 &dbquote( $hostie ) );
		}
	}

	my %outcome = &meta_get_records( Table => 'news_client',
					 Where => $whereclause );
	return %outcome;
}

sub nm_getlinks
{
	my %args = @_;
	my %outcome = ();

	my %recs = &nm_getnews( %args );

	foreach my $rid ( keys %recs )
	{
		my $lnk = $recs{ $rid } -> { "crosslink" };
		my $lng = $recs{ $rid } -> { "lng" };

		if( exists $outcome{ $lnk } )
		{
			$outcome{ $lnk } -> { $lng } = $recs{ $rid };
		} else
		{
			$outcome{ $lnk } = {};
			$outcome{ $lnk } -> { $lng } = $recs{ $rid };
		}
	}
	
# 	my %recs = &meta_get_records( Table => 'news',
# 					     Fields => [ 'id', 'crosslink', 'lng' ] );
# 	foreach my $rid ( keys %recs )
# 	{
# 		if( exists $outcome{ $recs{ $rid } -> { "crosslink" } } )
# 		{
# 			my $ar = $outcome{ $recs{ $rid } -> { "crosslink" } };
# 			push @$ar, $recs{ $rid } -> { "lng" };
# 			$outcome{ $recs{ $rid } -> { "crosslink" } } = $ar;
# 		} else
# 		{
# 			$outcome{ $recs{ $rid } -> { "crosslink" } } = [ $recs{ $rid } -> { "lng" } ];
# 		}
# 	}

	return %outcome;
}

sub nm_getid
{
	my ( $cross, $lng ) = @_;

	my %recs = &meta_get_records( Table => 'news',
				      Fields => [ 'id' ],
				      Where => sprintf( "crosslink=%s AND lng=%s", &dbquote( $cross ), &dbquote( $lng ) ) );
	return ${ [ keys %recs ] }[ 0 ];
}

sub nm_get_possible_languages
{
	my $newslnk = shift;

	my @outcome = ();
	my %recs = &meta_get_records( Table => 'news',
				      Fields => [ 'id', 'lng' ],
				      Where => sprintf( "crosslink=%s", &dbquote( $newslnk ) ) );

	foreach my $rid ( keys %recs )
	{
		push @outcome, $recs{ $rid } -> { 'lng' };
	}
	return @outcome;
}

1;

