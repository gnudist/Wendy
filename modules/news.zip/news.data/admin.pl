use strict;

package mod_news; # 'mod_' + MODULENAME

use XML::Quote;
use Date::Format;

use Wendy::Templates;
use Wendy::Hosts;
use Wendy::Db;
use Wendy::Util;

use Wendy::Modules::News;
use Date::Manip;
use Digest::MD5 'md5_hex';

use URI;

my $mybaseurl = "";
my $myid = "";
my $myhost = 0;

sub admin
{
	my $WOBJ = shift;


# 	my %outcome = (
# 		        data  => 'data',
# 			ctype => 'text/plain',
# 		        code  => 200,
# 			file => '' );

	my $ohtml = "";


# 	{
# 		use Data::Dumper;
# 		$outcome{ "data" } = 'Hello from generic Wendy module admin:<p>' . '<pre>' . Dumper( \%ENV ) . "\n" . Dumper( $WOBJ ) . '</pre>';
# 	}
	
	my $cgi = $WOBJ -> { "CGI" };

	$myhost = $cgi -> param( "host" );
	$myid   = $cgi -> param( "module" );
	$mybaseurl = '/admin/?action=modules&sub=invokeadm&host=' .
	             $myhost .
		     '&module=' .
		     $myid;

	$ohtml.=<<RAWHTML;
<h2>News module</h2>
[ <a href="$mybaseurl">refresh</a> ] [ <a href="${mybaseurl}&mac=new">new</a> ] [ <a href="${mybaseurl}&mac=clients">export clients</a> ] [ <a href="${mybaseurl}&mac=search">search news</a> ]
[ <a href="${mybaseurl}&mac=settings">settings</a> ]
RAWHTML

        my $mod_action = $cgi -> param( "mac" );

        &add_replace( 'HOSTID' => $myhost,
		      'CURRENT_MODULE_ACTION' => $mod_action,
		      'MODBASEURL' => $mybaseurl,
		      'MODULE_ID' => $myid );

        if( $mod_action eq 'new' )
        {
		my $mode = $cgi -> param( "fancy" );

		$ohtml .= &news_edit_form( WOBJ   => $WOBJ,
					   HostId => $myhost,
					   Action => 'create',
					   Date   => time2str( "%Y-%m-%d", time() ),
					   FancyEdit => ( $mode ? 1 : 0 ) );
	} elsif( $mod_action eq 'settings' )
        {
		my %options = &nm_get_options( $myhost );

		my $options_rows = '';
		my $i = 0;

		my $inv = $cgi -> param( 'mod_inv' );
		if( $inv )
		{
			my %new_options = ();
wkt7WFtWBNatz4By:
			while( 1 )
			{
				my $option = $cgi -> param( 'mod_option_' . $i );
				my $value = $cgi -> param( 'mod_value_' . $i );

				if( defined $option )
				{
					$i ++;
					if( $option and $value )
					{
						$new_options{ $option } = $value;
					}
				} else
				{
					last wkt7WFtWBNatz4By;
				}
			}


			my $newopname = $cgi -> param( 'mod_newopname' );
			my $newopval = $cgi -> param( 'mod_newopval' );

			if( $newopname and $newopval )
			{
				$new_options{ $newopname } = $newopval;
			}

			{
				&wdbbegin();
				my $sql = sprintf( "DELETE FROM news_settings WHERE host=%s",
						   &dbquote( $myhost ) );
				&wdbdo( $sql );

				foreach my $opname ( keys %new_options )
				{
					my $sql = sprintf( "INSERT INTO news_settings (host,field,value) VALUES (%s,%s,%s)",
							   map { &dbquote( $_ ) } ( $myhost,
										    $opname,
										    $new_options{ $opname } ) );
					&wdbdo( $sql );
				}

				unless( &wdbcommit() )
				{
					&wdbrollback();
					$ohtml .= &__htmlerrmsg( &wdbgeterror() );
				}
			}


			%options = %new_options;

			$i = 0;
		}

		foreach my $option ( sort { $a cmp $b } keys %options )
		{
			$options_rows .= '<tr>' .
			                 '<td>' .
					 '<input type="text" name="' .
					 'mod_option_' .
					 $i .
					 '" value="' .
					 xml_quote( $option ) .
					 '">' .
					 '</td>' .
					 '<td>' .
					 '<input size="60" type="text" name="' .
					 'mod_value_' .
					 $i .
					 '" value="' .
					 xml_quote( $options{ $option } ) .
					 '">' .
					 '</td>' .
					 '</tr>';
		} continue { $i ++ }

		&add_replace( 'OPTIONS_ROWS' => $options_rows );
		my $t_proc = &template_process( '__mod_news_settings' );
		$ohtml .= $t_proc -> { "data" };

	} elsif( $mod_action eq 'create' )
        {
		my ( $title,
		     $body,
		     $crdate,
		     $lng,
		     $lnk ) = map { scalar $cgi -> param( $_ ) } ( "mod_title",
								   "mod_body",
								   "mod_date",
								   "mod_lng",
								   "mod_lnk" );

		my $newid = int( $lnk );

		unless( &wdbbegin() )
		{
			die &wdbgeterror();
		}
		
		unless( $newid )
		{
			$newid = &seqnext( 'news_crosslnk' );
			my $sql = sprintf( "INSERT INTO news_crosslink VALUES ( %s )",
					   &dbquote( $newid ) );
		
			unless( &wdbdo( $sql ) )
			{
				$ohtml .= &__htmlerrmsg( &wdbgeterror() );
				&wdbrollback();
			}
		}

		my $sql = sprintf( "INSERT INTO news (author,published,host,lng,crosslink,state,title,body) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",
				   map { &dbquote( $_ ) } ( $WOBJ -> { "USER" } -> { "id" },
							    $crdate,
							    $myhost,
							    $lng,
							    $newid,
							    NS_PENDING,
							    $title,
							    $body ) );
				   
###		$VAR1 = { 'HPATH' => 'admin', 'LNG' => 'en', 'HOST' => { 'HOSTPATH' => 'eric_jaja_sp', 'defaultlng' => '1', 'id' => '1', 'host' => 'eric.jaja.sp' }, 'COOKIES' => {}, 'TPLSTORE' => '/var/www/wendy/var/hosts/eric.jaja.sp/tpl', 'RLNGS' => { 'en' => '1' }, 'CGI' => bless( { '.parameters' => [ 'action', 'sub', 'host', 'module', 'mac', 'news_id', 'mod_title', 'mod_date', 'mod_lng', 'mod_body' ], 'mod_date' => [ '2007-09-13' ], 'news_id' => [ '0' ], 'host' => [ '1' ], 'mod_lng' => [ '1' ], '.r' => bless( do{\(my $o = 140714848)}, 'Apache2::RequestRec' ), '.charset' => 'ISO-8859-1', 'sub' => [ 'invokeadm' ], 'mod_body' => [ '' ], 'action' => [ 'modules' ], '.fieldnames' => {}, 'mod_title' => [ '' ], 'mac' => [ 'create' ], 'escape' => 1, 'module' => [ '43' ] }, 'CGI' ), 'DBH' => bless( {}, 'Apache::DBI::db' ), 'HANDLERSRC' => '/var/www/wendy/var/hosts/eric.jaja.sp/lib/admin.pl', 'USER' => { 'password' => 'toor', 'id' => '1', 'flag' => '0', 'login' => 'root', 'host' => '1' }, 'REQREC' => bless( do{\(my $o = 140714848)}, 'Apache2::RequestRec' ) };

# 		use Data::Dumper;

		if( &wdbdo( $sql ) )
		{
			$ohtml .= &__htmlokmsg( 'OK' );
			&wdbcommit();

		} else
		{
			$ohtml .= &__htmlerrmsg( &wdbgeterror() ) . '<p><a href="javascript:history.back()">back</a>';
			&wdbrollback();
		}
        } elsif( $mod_action eq 'open' )
        {
		my ( $news_id,
		     $crosslink,
		     $lng ) = map { scalar $cgi -> param( $_ ) } ( 'mod_news_id',
								   'mod_lnk',
								   'mod_lng' );

		unless( $news_id )
		{
			if( $crosslink and $lng )
			{
				$news_id = &nm_getid( $crosslink, $lng );
			}
		}


		my %nrecs = &nm_getnews( Id => $news_id );
		my $mode = $cgi -> param( "fancy" );

		my $ts = time();

		my $pd_published = ParseDate( $nrecs{ $news_id } -> { "published" } );

		if( $pd_published )
		{
			$ts = UnixDate( $pd_published, "%s" );
		}

		$ohtml .= &news_edit_form( WOBJ   => $WOBJ,
					   HostId => $myhost,
					   Action => 'update',
					   Date   => time2str( "%Y-%m-%d", $ts ),
					   NId    => $news_id,
					   Body   => $nrecs{ $news_id } -> { "body" },
					   Title  => $nrecs{ $news_id } -> { "title" },
					   Lng    => $nrecs{ $news_id } -> { "lng" },
					   FancyEdit => ( $mode ? 1 : 0 ) );


	} elsif( $mod_action eq 'update' )
        {
		my ( $title,
		     $body,
		     $crdate,
		     $lng,
		     $id ) = map { scalar $cgi -> param( $_ ) } ( "mod_title",
								  "mod_body",
								  "mod_date",
								  "mod_lng",
								  "mod_news_id" );

		my $sql = sprintf( "UPDATE news SET published=%s,title=%s,body=%s,lng=%s WHERE id=%s",
				   map { &dbquote( $_ ) } ( $crdate, $title, $body, $lng, $id ) );

		if( &wdbdo( $sql ) )
		{
			$ohtml .= &__htmlokmsg( 'OK' );
		} else
		{
			$ohtml .= &__htmlerrmsg( &wdbgeterror() );
		}

	} elsif( $mod_action eq 'addlng' )
        { 
		my $news_id = $cgi -> param( 'mod_news_id' );

		unless( $news_id )
		{
			my $crosslink = $cgi -> param( "mod_lnk" );
			my %news = &nm_getnews( Crosslink => $crosslink );
			$news_id = ${ [ keys %news ] }[ 0 ];
		}

		my %nrecs = &nm_getnews( Id => $news_id );

		my $mode = $cgi -> param( "fancy" );
		my $ts = time();
		my $pd_published = ParseDate( $nrecs{ $news_id } -> { "published" } );

		if( $pd_published )
		{
			$ts = UnixDate( $pd_published, "%s" );
		}

		$ohtml .= &news_edit_form( WOBJ   => $WOBJ,
					   HostId => $myhost,
					   Action => 'create',
					   Date   => time2str( "%Y-%m-%d", $ts ),
					   NId    => 0,
					   Body   => $nrecs{ $news_id } -> { "body" },
					   Lnk    => $nrecs{ $news_id } -> { "crosslink" },
					   Title  => $nrecs{ $news_id } -> { "title" },
					   Lng    => scalar $cgi -> param( "mod_lng" ),
					   FancyEdit => ( $mode ? 1 : 0 ) );

	} elsif( $mod_action eq 'setexport' )
        {
		my $news_lnk = $cgi -> param( "mod_lnk" );

		my ( $states_html,
		     $exports_html,
		     $errors_html ) = ( "", "", "" );

		my @lngs = &nm_get_possible_languages( $news_lnk );
		my %languages = &meta_get_records( Table  => 'language' );
		my %states = &nm_getstates();
		my %clients = &nm_getclients( Host => $WOBJ -> { 'HOST' } -> { 'id' } );
		my %ex_clients = &nm_getclients( Crosslink => $news_lnk,
						 Host => $WOBJ -> { 'HOST' } -> { 'id' } );

		my $inv = $cgi -> param( "mod_inv" );
		
		if( defined $inv )
		{
			my $sql = sprintf( "SELECT id FROM news WHERE crosslink=%s",
					   &dbquote( $news_lnk ) );
			my $sth = &dbprepare( $sql );
			$sth -> execute();
			while( my $data = $sth -> fetchrow_hashref() )
			{
				my $new_state = $cgi -> param( "state_" . $data -> { "id" } );
				if( defined $new_state )
				{

					my $sql = sprintf( "UPDATE news SET state=%s WHERE id=%s",
							   &dbquote( $new_state ),
							   &dbquote( $data -> { "id" } ) );
					
					unless( &wdbdo( $sql ) )
					{
						$errors_html .= &__htmlerrmsg( "ERROR: " . &wdbgeterror() );
					}
				}
			}
			$sth -> finish();

			my $clients_updated = 0;

			foreach my $cid ( keys %clients )
			{
				my $export_to_him = $cgi -> param( "exportto_" . $cid );
				my $sql = "SELECT 1";

				if( defined $export_to_him )
				{
					unless( exists $ex_clients{ $cid } )
					{

						$clients_updated = 1;
						$sql = sprintf( "INSERT INTO news_export (client,news) VALUES (%s,%s)",
								&dbquote( $cid ),
								&dbquote( $news_lnk ) );
					}
				} else
				{
					$clients_updated = 1;
					$sql = sprintf( "DELETE from news_export WHERE client=%s AND news=%s",
							&dbquote( $cid ),
							&dbquote
							( $news_lnk ) );


				}

				unless( &wdbdo( $sql ) )
				{
					$errors_html .= &__htmlerrmsg( "ERROR: " . &wdbgeterror() );
				}


			}
			if( $clients_updated )
			{
				%ex_clients = &nm_getclients( Crosslink => $news_lnk );
			}

		}


		my %news = &nm_getlinks( Crosslink => $news_lnk );


		$states_html .= '<table border="1">';

		foreach my $lng ( sort { $languages{ $a } -> { "lng" }
					 cmp 
					 $languages{ $b } -> { "lng" } } @lngs )
		{

			my $states_select = '<SELECT name="state_' .
                                            $news{ $news_lnk } -> { $lng } -> { "id" } .
					    '">';
			foreach my $sid ( sort { $a <=> $b } keys %states )
			{
				$states_select .= '<OPTION value="' .
				                  $sid .
						  '"' .
						  ( $sid == $news{ $news_lnk } -> { $lng } -> { "state" } ? ' SELECTED' : '' ) .
						  '>' .
						  $states{ $sid } -> { "state" } .
						  '</OPTION>';
			}
			$states_select .= '</SELECT>';

	  



			$states_html .= '<tr><td>' .
			                $languages{ $lng } -> { "lng" } .
					'</td>' .
					'<td>' .
					xml_quote( $news{ $news_lnk } -> { $lng } -> { "title" } ) .
					'</td>' .
					'<td>' .
					$states_select .
					'</td>' .
					'</tr>';
					
		}
		$states_html .= '</table>';


		foreach my $cid ( sort { $clients{ $a } -> { "name" }
					 cmp
					 $clients{ $b } -> { "name" } } keys %clients )
		{
			
			$exports_html .= '<tr bgcolor="#eeeeee">' .
			                 '<td>' .
					 $clients{ $cid } -> { "name" } .
					 '</td>' .
					 '<td>' .
					 '<input type="checkbox" name="exportto_' .
					 $cid .
					 '"' .
					 ( exists $ex_clients{ $cid } ? ' CHECKED' : '' ) .
					 '>' .
					 '</td>' .
					 '</tr>';
		}
		
		&add_replace( 'NEWS_LNK'     => $news_lnk,
			      'ERRORS_HTML'  => $errors_html,
			      'STATES_HTML'  => $states_html,
			      'EXPORTS_HTML' => $exports_html );
		
		my $t_proc = &template_process( '__mod_news_set_state_export' );
		return $t_proc;

	} elsif( $mod_action eq 'delete' )
        {
		my $news_id = $cgi -> param( 'mod_news_id' );
		my $news_lnk = 0;


		unless( $news_lnk )
		{
			my %recs = &meta_get_records( Table => 'news',
						      Fields => [ 'id', 'crosslink' ],
						      Where => sprintf( "id=%s", &dbquote( $news_id ) ) );
			
			if( scalar keys %recs )
			{

				$news_lnk = $recs{ $news_id } -> { "crosslink" };
			}

		}
		if( $news_lnk )
		{
			&wdbbegin();

			my $sql = sprintf( "DELETE from news WHERE id=%s", &dbquote( $news_id ) );

			&wdbdo( $sql );

			my %recs = &meta_get_records( Table => 'news',
						      Fields => [ 'id' ],
						      Where => sprintf( "crosslink=%s", &dbquote( $news_lnk ) ) );

			if( scalar keys %recs == 0 )
			{
				map { &wdbdo( $_ ) } ( sprintf( "DELETE from news_export WHERE news=%s",
							       &dbquote( $news_lnk ) ),
						      sprintf( "DELETE from news_crosslink WHERE id=%s",
							       &dbquote( $news_lnk ) ) );
			}
			
			if( &wdbcommit() )
			{
				$ohtml .= &__htmlokmsg( 'Deleted.' );
			} else
			{
				&wdbrollback();
				$ohtml .= &__htmlerrmsg( &wdbgeterror() );
			}
		} else
		{
			$ohtml .= &__htmlerrmsg( 'Bad news id' );
		}



		
	} elsif( $mod_action eq 'clients' )
        { 

		my $hosts = &all_hosts();
		my $hostname = $hosts -> { $myhost } -> { "host" };
		my $export_url = URI -> new();
		$export_url -> scheme( 'http' );
		$export_url -> host( $hostname );
		$export_url -> path( '/mod/news/export/' );

		my %clients = &nm_getclients( Host => $myhost );
		
		my $clients_html ="";

		unless( scalar keys %clients )
		{
			$clients_html .= "Total: " . int( scalar keys %clients );
		}

		my ( $lightrow, $darkrow ) = ( '#eeeeee', '#cccccc' );
		my $i = 0;
		foreach my $cid ( sort { $clients{ $a } -> { "name" }
					 cmp
                                         $clients{ $b } -> { "name" } } keys %clients )
		{

			$export_url -> query_form( cid => $cid );

			$clients_html .= '<tr bgcolor="' .
			                 ( $i % 2 ? $lightrow : $darkrow ) .
					 '">' .
					 '<td>' .
					 $cid .
					 '</td>' .
					 '<td>' .
					 xml_quote( $clients{ $cid } -> { "name" } ) .
					 '</td>' .
					 '<td>' .
					 ' [ <a title="Delete client" onClick="return confirm(\'Really delete ' . xml_quote( $clients{ $cid } -> { "name" } ) . '?\')" href="' .
					 $mybaseurl .
					 '&mac=deleteclient' .
					 '&mod_client=' .
					 $cid .
					 '">x</a> ] ' .
					 ' [ <a title="Edit client" href="' .
					 $mybaseurl .
					 '&mac=editclient' .
					 '&mod_client=' .
					 $cid .
					 '">edit</a> ] ' .
					 '</td>' .
					 '<td>' .
					 '[ <a href="' .
					 $export_url -> canonical() -> as_string() .
					 '">' .
					 'link' .
					 '</a> ]' .
					 '</td>' .
					 '</tr>';
			    
		} continue { $i ++ }

		&add_replace( 'CLIENTS_LIST_ROWS' => $clients_html );
		my $t_proc = &template_process( '__mod_news_clients_list' );
		$ohtml .= $t_proc -> { "data" };
	} elsif( $mod_action eq 'deleteclient' )
        {
		my $client_id = $cgi -> param( "mod_client" );
		
		&wdbbegin();
		my $sql = sprintf( "DELETE from news_export WHERE client=%s",
				   &dbquote( $client_id ) );
		&wdbdo( $sql );
		$sql = sprintf( "DELETE FROM news_client WHERE id=%s AND host=%s",
				&dbquote( $client_id ),
				&dbquote( $myhost ) );
		&wdbdo( $sql );

		if( &wdbcommit() )
		{
			$ohtml .= &__htmlokmsg( "Deleted client " . $client_id );
		} else
		{
			&wdbrollback();
			$ohtml .= &__htmlerrmsg( "ERROR: " . &wdbgeterror() );
		}
	} elsif( $mod_action eq 'newclient' )
        {
		$ohtml .= &client_edit_form( WOBJ   => $WOBJ,
					     HostId => $myhost,
					     Action => 'addclient' );


	} elsif( $mod_action eq 'addclient' )
        { 
		my $clientname = $cgi -> param( "mod_clientname" );
		my $sql = sprintf( "INSERT INTO news_client (name,host) VALUES (%s,%s)",
				   &dbquote( $clientname ),
				   &dbquote( $myhost ) );
		if( &wdbdo( $sql ) )
		{
			$ohtml .= &__htmlokmsg( "OK" );
		} else
		{
			$ohtml .= &__htmlerrmsg( "ERROR: " . &wdbgeterror() );
		}
	} elsif( $mod_action eq 'editclient' )
        {
		my $client_id = $cgi -> param( "mod_client" );
		my %clients = &nm_getclients( Id => $client_id );

		if( scalar keys %clients )
		{
			
			$ohtml .= &client_edit_form( WOBJ   => $WOBJ,
						     HostId => $myhost,
						     Action => 'updateclient',
						     Name   => $clients{ $client_id } -> { "name" },
						     Id     => $client_id );
		} else
		{
			$ohtml .= &__htmlerrmsg( "Wrong client ID" );
		}

	} elsif( $mod_action eq 'updateclient' )
        {
		my ( $client_id,
		     $clientname ) = map { scalar $cgi -> param( $_ ) } (
									 'mod_client',
									 'mod_clientname' );
		
		my $sql = sprintf( "UPDATE news_client SET name=%s WHERE id=%s",
				   &dbquote( $clientname ),
				   &dbquote( $client_id ),
				   &dbquote( $myhost ) );

		if( &wdbdo( $sql ) )
		{
			$ohtml .= &__htmlokmsg( "OK" );
		} else
		{
			$ohtml .= &__htmlerrmsg( "ERROR: " . &wdbgeterror() );
		}

	} elsif( $mod_action eq 'search' )
        {
		my $mod_inv = $cgi -> param( "mod_inv" );

		my ( $from,
		     $to,
		     $str,
		     $looktitles,
		     $lookbodies ) = map { scalar $cgi -> param( $_ ) } ( 'mod_from',
									  'mod_to',
									  'mod_str',
									  'mod_checktitle',
									  'mod_checkbody' );
		
		
		my $found_html = "";

		unless( $mod_inv )
		{
			$from = time2str( "%Y-%m-%d", 1 );
			$to = time2str( "%Y-%m-%d", time() + 24 * 60 * 60 );
			$str = "";
			$looktitles = 'CHECKED';
			$lookbodies = 'CHECKED';

		}

		if( $mod_inv )
		{
			my %news = &nm_getlinks( From      => $from,
						 Host      => $myhost,
						 TitleLike => ( $looktitles ? $str : undef ),
						 BodyLike => ( $lookbodies ? $str : undef ),
						 To        => $to );

			if( scalar keys %news )
			{

				$found_html .= &__form_rows_html( \%news );
			} else
			{
				$found_html .= "Found nothing.";
			}
		}

		&add_replace( 'FROM_DATE' => $from,
			      'TO_DATE' => $to,
			      'SEARCH_STR' => xml_quote( $str ),
			      'TITLE_CHECKED' => $looktitles,
			      'BODY_CHECKED' => $lookbodies,
			      'NEWS_LIST_ROWS' => $found_html );

		my $t_proc = &template_process( '__mod_news_search' );
		$ohtml .= $t_proc -> { "data" };

	} else
        { # show news list

		my ( $from_date,
		     $to_date,
		     $id_value ) = map { scalar $cgi -> param( $_ ) } ( 'mod_from',
									'mod_to',
									'mod_lnk' );

		unless( $from_date )
		{
			$from_date = time2str( "%Y-%m-%d", time() - 30 * 24 * 60 * 60 );
		}

		unless( $to_date )
		{
			$to_date = time2str( "%Y-%m-%d", time() );
		}
                # TODO: add host specification
		my %news = &nm_getlinks( From      => $from_date,
					 To        => $to_date,
					 Host      => $myhost,
					 Crosslink => ( $id_value ? $id_value : undef ) );

		my $rows_html = &__form_rows_html( \%news );

		&add_replace( 'NEWS_LIST_ROWS' => $rows_html,
			      'FROM_DATE' => $from_date,
			      'TO_DATE' => $to_date,
			      'ID_VALUE' => $id_value );
		my $t_proc = &template_process( '__mod_news_news_list' );
		$ohtml .= $t_proc -> { "data" };

        }

	return $ohtml;
}

sub news_edit_form
{
	my %args = @_;

	my ( $action,
	     $wobj,
	     $host,
	     $news_title,
	     $news_date,
	     $news_body,
	     $news_id,
	     $force_lnk,
	     $language,
	     $fancy ) = @args{ "Action",
			       "WOBJ",
			       "HostId",
			       "Title",
			       "Date",
			       "Body",
			       "NId",
			       "Lnk",
			       "Lng",
			       "FancyEdit" };

	{
		map { $_ = xml_quote( $_ ) } ( $news_title, $news_date, $news_body );
	}

	my $template = '__mod_news_edit_form';

	if( $fancy )
	{
		$template = '__mod_news_edit_form_fancy';
	}

	my $lng_options = "";

	unless( $language )
	{
		$language = $wobj -> { "HOST" } -> { 'defaultlng' };
	}

	{
		my %languages = &get_host_languages( $host );

		foreach my $lid ( sort { $languages{ $a } cmp $languages{ $b } } keys %languages )
		{
			$lng_options .= '<OPTION VALUE="' .
			                $lid .
					'"' .
					( $lid == $language ? ' SELECTED' : '' ) .
					'>' .
					$languages{ $lid } .
					'</OPTION>';
		}
	}


        &add_replace( 'NEWS_TITLE' => $news_title,
		      'NEWS_DATE'  => $news_date,
		      'NEWS_BODY'  => $news_body,
		      'FORCE_LNK'  => $force_lnk,
		      'FORCE_LNG'  => $language,
		      'NEWS_ID'    => int( $news_id ),
		      'LANGUAGES_OPTIONS' => $lng_options,
		      'MODULE_ACTION' => $action );

	my $t_proc = &template_process( $template );
	return $t_proc -> { "data" };
}

sub client_edit_form
{
	my %args = @_;

	my ( $action,
	     $wobj,
	     $host,
	     $clientname,
	     $client_id ) = @args{ "Action",
				   "WOBJ",
				   "HostId",
				   "Name",
				   "Id" };
	$clientname = xml_quote( $clientname );
	my $template = '__mod_news_client_edit_form';
	
        &add_replace( 'CLIENT_NAME'   => $clientname,
		      'CLIENT_ID'     => int( $client_id ),
		      'CLIENT_ACTION' => $action );

	my $t_proc = &template_process( $template );
	return $t_proc -> { "data" };
}

sub __htmlerrmsg
{
	my $msg = shift;

	return '<font color="red">' .
	       xml_quote( $msg ) .
	       '</font>';

}

sub __htmlokmsg
{
	my $msg = shift;

	return '<font color="green">' .
	       xml_quote( $msg ) .
	       '</font>';

}

sub __form_rows_html
{
	my $news = shift;
	my %news = %$news;

	my $rows_html = "";

	my %languages = &meta_get_records( Table  => 'language' );
	my %host_languages = &get_host_languages( $myhost );
	
	my @uniq_lnks = ();
	
	
	my ( $lightrow, $darkrow ) = ( '#eeeeee', '#cccccc' );
	my $clients_height = 0;
	
	{
		my %clients = &nm_getclients();
		$clients_height = ( scalar keys %clients ) * 25 + 200;
	}
	
	my $i = 0;
	
	foreach my $lnk_nid ( sort { $b
				     <=>
				     $a }
			      keys %news )
	{
		
		my @available_languages = keys %{ $news{ $lnk_nid } };
		
		$clients_height = $clients_height + ( scalar @available_languages * 25 );
		
		my $addlanguage_html = "";
		
		{
			my @addlanguages = ();
			
			foreach my $hlid ( keys %host_languages )
			{
				unless( &in( $hlid, @available_languages ) )
				{
					push @addlanguages, $hlid;
				}
			}
			
			if( scalar @addlanguages )
			{
				
				$addlanguage_html .=<<RAWHTML;
<form method="POST" action="/admin/">
<input type="hidden" name="action" value="modules">
<input type="hidden" name="sub" value="invokeadm">
<input type="hidden" name="host" value="$myhost">
<input type="hidden" name="module" value="$myid">
<input type="hidden" name="mac" value="addlng">
<input type="hidden" name="mod_lnk" value="$lnk_nid">
				    
RAWHTML

                                $addlanguage_html .= '<table border="0"><tr><td>+&nbsp;<SELECT name="mod_lng" id="addLanguageSel' .
				$lnk_nid .
				'" onChange="displaySubmit(\'addLanguageSel' .
				$lnk_nid .
				'\', \'addLanguage' .
				$lnk_nid .
				'\')" id="newLngSel"><OPTION value="0"> ... </OPTION>';
				
				foreach my $hlid ( sort { $host_languages{ $a }
							  cmp
							  $host_languages{ $b } }
						   @addlanguages )
				{
					$addlanguage_html .= '<OPTION value="' .
					    $hlid .
					    '">' .
					    $host_languages{ $hlid } .
					    '</OPTION>';
				}
				$addlanguage_html .= '</SELECT></td><td><div id="addLanguage' .
				    $lnk_nid .
				    '">&nbsp;</div></td></tr></table></form>';
				
				
			}
			
		}
		
		my $title_open_html = "";
		
		{
			my $linked_news = $news{ $lnk_nid };
			
			$title_open_html .= '<table border="0">';
			
			foreach my $lngid ( sort { $host_languages{ $a }
						   cmp
						   $host_languages{ $b } } keys %$linked_news )
			{
				$title_open_html .= '<tr>' .
				    '<td>' .
				    '<a title="Open" href="' .
				    $mybaseurl .
				    '&mac=open' .
				    '&mod_news_id=' .
				    $linked_news -> { $lngid } -> { "id" } .
				    '">' .
				    $host_languages{ $lngid } .
				    '</a>' .
				    '</td>' .
				    '<td>' .
				    time2str( "%Y-%m-%d", UnixDate( ParseDate( $linked_news -> { $lngid } -> { "published" } ), "%s" ) ) .
				    '</td>' .
				    '<td>' .
				    $linked_news -> { $lngid } -> { "title" } .
				    '</td>' .
				    '<td>' .
				    '[&nbsp;<a title="Delete" onClick="return confirm(\'Really delete?\')" href="' .
				    $mybaseurl .
				    '&mac=delete' .
				    '&mod_news_id=' .
				    $linked_news -> { $lngid } -> { "id" } .
				    '">' .
				    'x' .
				    '</a>' .
				    '&nbsp;]' .
				    '</td>' .
				    '</tr>';
			}
			$title_open_html .= '</table>';
			
		}
		
		$rows_html .= '<tr bgcolor="' .
		    ( $i % 2 ? $lightrow : $darkrow ) .
		    '">' .
		    '<td valign="top">' .
		    $lnk_nid .
		    '</td>' .
		    '<td valign="top">' .
		    $title_open_html .
		    '</td>' .
		    '<td valign="top">' .
		    ( $addlanguage_html or '&nbsp;' ) .
		    '</td>' .
		    '<td valign="top">' .
		    '[ <a href="javascript:void(0)" ' .
		    'onClick="window.open(' .
		    '\'' .
		    $mybaseurl .
		    '&mac=setexport' .
		    '&mod_lnk=' .
		    $lnk_nid .
		    '\',' .
		    '\'' .
		    md5_hex( rand() ) .
		    '\',' .
		    '\'width=300,height=' .
		    $clients_height .
		    '\')">status/export</a> ]' .
		    '</td>' .
		    '</tr>';
		
	} continue { $i ++ }
	
	return $rows_html;
	
}

1;

