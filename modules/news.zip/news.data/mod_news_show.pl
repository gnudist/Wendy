use strict;

package mod_news_show;

use Wendy::Templates;
use Wendy::Modules::News;
use XML::Quote;

sub wendy_handler
{
	my $WOBJ = shift;
	&sload_macros();

	my $news = $WOBJ -> { 'CGI' } -> param( 'news' );
	
	my %newsrec = &nm_getnews( Crosslink => $news,
				   Lng  => $WOBJ -> { "RLNGS" } -> { $WOBJ -> { "LNG" } },
				   Host => $WOBJ -> { 'HOST' } -> { 'id' },
				   State => NS_APPROVED );

	use Data::Dumper;

	&add_replace( 'NEWS_DUMP' => xml_quote( Dumper( \%newsrec ) ) );

	my $t_proc = &template_process( 'mod_news_show' );
	$t_proc -> { "ttl" } = 10;

	return $t_proc;
}

1;
